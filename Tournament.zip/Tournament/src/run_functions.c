#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
#include <nonPRL.h>
int get_red_cube(){
    printf("getting red cube\n");
    P_square_up(870);
    drive_to(2);
    center_turn(left,90);
    square_up(1,-870); 
    servo(2,400,2);
    servo(1,700,2);
    drive_to(-17);
    center_turn(right,10);
    drive_to(-4);
    servo(1,1400,2);
    center_turn(left,10);
    servo(2,675,2);
    drive_to(8);
    servo(2,1500,2);
    return 0;
}