#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
#include <nonPRL.h>
#include <RSe_lib.h>
int main(){
    set_servo_position(0,1285);
    set_servo_position(1,1200);
    set_servo_position(2,1600);
    enable_servos();
    mav(2,500);
    mav(0,500);
    msleep(500);
    //Wheel_Calibration();
    //spin_motor(left, 1740, 500);
    //msleep(3000);
    //spin_motor(left, 1800, -500);
    //set_wheel_ticks(1740, 1800);//left is 1800 in reverse 
    //center_turn(left,90);
    //msleep(3000);
    //center_turn(right,90);
    
    //square_up(2,600);
    //square_up(1,600);
    //drive_to(-10);
    //center_turn(right, 90);
    //get_red_cube();
    //center_turn(left,90);
    //d_drive(100,100);
    return 0;
}
