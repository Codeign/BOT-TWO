#include <kipr/wombat.h>
#include <RSe_lib.h>
#include <stdlib.h>

float srv_min_max[4][2]={
    /*min       max*/
    {1024 	,   1024},//0
    {1024  	,   1024},//1
    {1024  	,   1024},//2
    {1024  	,   1024} //3
};

thread servo_cntrl;
thread chronos_thread;

float current_time;
///////// _________________________________________ Utility _________________________________________ (4/28/2022)

int destroy_threads(){
    int i=0;
    if(servo_raw[0][0]>-1){thread_destroy(servo_cntrl);i=i+1;}
    if(servo_scheduled[0][3]>-1){thread_destroy(chronos_thread);i=i+1;}
    printf("Destroyed (%d) threads\n",i);
    return i;
}

///////// _________________________________________ Chronos _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ (4/28/2022)

void chronos_trigger(){
    printf("Thread [chronos] started\n");
    if(servo_raw[0][0]<0){servo_cntrl = thread_create(threaded_servo_controler);thread_start(servo_cntrl);}
    //start smart servo
    servo_scheduled[0][3]=1;
    int i;
    while(1){
        current_time=seconds();
        i=0;
        while(i<4){
            if(current_time>=servo_scheduled[i][2] && !(servo_scheduled[i][3])){
                servo_raw[i][1]=servo_scheduled[i][0];
                servo_raw[i][2]=abs(servo_raw[i][1]-servo_raw[i][0])/(servo_scheduled[i][1]*servo_theta);
                servo_scheduled[i][3]=1;
                servo_raw[i][3]=0;
            }
            //printf("%d ",abs(servo_raw[i][0]-servo_raw[i][1]));
            if(!servo_raw[i][3] && abs(servo_raw[i][0]-servo_raw[i][1])<7){
                servo_raw[i][2]=1;
                servo_raw[i][3]=1;
                printf("servo %d's destination reached\n",i);
            }
            i=i+1;
        }
        msleep(20);
        
    }
}

int wait_for_smart(int port){	
    // needs to function with scheduled servos. Likely need to rewrite all the code in the future
    // for now it only works with in progress movements -ReeSe
    if(port<0 || port>3){printf("ERROR: Out of bounds port number for wait_for_smart()\n");return -1;}
    while(servo_raw[port][3]!=1){
        msleep(400);
    }
    return 1;
}

///////// ________________________________________ Smart Servo ________________________________________ (4/28/2022)

//|curr pos|      |target pos|   |tks/10ms|   |position reached|
//|target perc|   |seconds|      |delay|      |activated|
float servo_raw[4][4]={{-5,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
float servo_scheduled[4][4]={{0,0,0,-1},{0,0,0,1},{0,0,0,1},{0,0,0,1}};

void smart_servoX(int port, int perc, float time, float delay)
{
    if(servo_raw[0][0]<0){servo_cntrl=thread_create(threaded_servo_controler);thread_start(servo_cntrl);msleep(50);}
    if(servo_scheduled[0][3]<0){chronos_thread=thread_create(chronos_trigger);thread_start(chronos_thread);msleep(50);}
    if(port>-1){

        if(delay<=0){
            servo_raw[port][1]=((srv_min_max[port][1]-srv_min_max[port][0])*(perc/100.0)+srv_min_max[port][0]);
            servo_raw[port][2]=abs(servo_raw[port][1]-servo_raw[port][0])/(time*servo_theta);
            servo_raw[port][3]=0;
        }else{
            servo_scheduled[port][0]=((srv_min_max[port][1]-srv_min_max[port][0])*(perc/100.0)+srv_min_max[port][0]);
            servo_scheduled[port][1]=time;
            servo_scheduled[port][2]=delay+seconds();
            servo_scheduled[port][3]=0;
        }
    }
}

void threaded_servo_controler()
{
    printf("Thread [smart servo] started\n");
    enable_servos();
    servo_raw[0][0]=get_servo_position(0);
    servo_raw[1][0]=get_servo_position(1);
    servo_raw[2][0]=get_servo_position(2);
    servo_raw[3][0]=get_servo_position(3);
    while(1)
    {
        if(servo_raw[0][1]>servo_raw[0][0]){
        servo_raw[0][0]=servo_raw[0][0]+servo_raw[0][2];
        }else{
            servo_raw[0][0]=servo_raw[0][0]-servo_raw[0][2];
        }
        set_servo_position(0,(int)servo_raw[0][0]);
        if(servo_raw[1][1]>servo_raw[1][0]){
            servo_raw[1][0]=servo_raw[1][0]+servo_raw[1][2];
        }else{
            servo_raw[1][0]=servo_raw[1][0]-servo_raw[1][2];
        }
        set_servo_position(1,(int)servo_raw[1][0]);
        if(servo_raw[2][1]>servo_raw[2][0]){
        servo_raw[2][0]=servo_raw[2][0]+servo_raw[2][2];
        }else{
            servo_raw[2][0]=servo_raw[2][0]-servo_raw[2][2];
        }
        set_servo_position(2,(int)servo_raw[2][0]);
        if(servo_raw[3][1]>servo_raw[3][0]){
            servo_raw[3][0]=servo_raw[3][0]+servo_raw[3][2];
        }else{
            servo_raw[3][0]=servo_raw[3][0]-servo_raw[3][2];
        }
        set_servo_position(3,(int)servo_raw[3][0]);
        msleep(10);
    }
}
