

///////// _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ Utility _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ (4/28/2022)
int destroy_threads();

///////// _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ Chronos _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ (4/28/2022)
void chronos_trigger();
float current_time;
int wait_for_smart(int port);

///////// _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ Smart Servo _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ (4/28/2022)
#define percent_default 50
#define time_default 1.5
#define delay_default 0

#define servo_theta 87
//		|curr pos|   |percentage|   |tks/10ms|   |delay|
//		|target perc|   |delay| |activated|
float srv_min_max[4][2];
float servo_raw[4][4];
float servo_scheduled[4][4];
void smart_servoX(int port, int perc, float time, float delay);
void threaded_servo_controler();



///////// _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ Mass Define _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ (4/28/2022)
#define smart_servo(...)      vrg(smart_servo, __VA_ARGS__)
#define smart_servo1(x)       smart_servoX(x,percent_default,time_default,delay_default)
#define smart_servo2(x,y)     smart_servoX(x,y,time_default,delay_default)
#define smart_servo3(x,y,z)   smart_servoX(x,y,z,delay_default)
#define smart_servo4(x,y,z,i) smart_servoX(x,y,z,i)

#define vrg_cnt(vrg1,vrg2,vrg3,vrg4,vrg5,vrg6,vrg7,vrg8,vrgN, ...) vrgN
#define vrg_argn(...)  vrg_cnt(__VA_ARGS__, 8, 7, 6, 5, 4, 3, 2, 1, 0)
#define vrg_cat0(x,y)  x ## y
#define vrg_cat(x,y)   vrg_cat0(x,y)
#define vrg(vrg_f,...) vrg_cat(vrg_f, vrg_argn(__VA_ARGS__))(__VA_ARGS__)