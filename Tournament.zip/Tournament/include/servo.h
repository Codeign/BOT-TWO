void update_servos();
void clear_servos();
void load_servo(int port, int position, int speed);
void servo(int port,int position,int speed);