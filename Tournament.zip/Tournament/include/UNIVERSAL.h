void drive(float distance, int speed);
void line_follow(float distance, int speed, int port, char side);
void right_turn(float degree, float speed, double radius);
void left_turn(float degree, float speed, double radius);
void square(int speed);