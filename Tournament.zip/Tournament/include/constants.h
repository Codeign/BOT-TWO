#define right_wheel 2
#define left_wheel 0
#define pi 3.14159265359
#define D_Wheel_Diameter 2.755905
#define D_Distance_Between_Wheels 7.12500
float left_speed;
float right_speed;
int create_in_use;

float wheel_circumference;
float distance_between_wheels;
float right_wheel_tpr;
float left_wheel_tpr;
float right_wheel_tpc;
float left_wheel_tpc;
float pivot;

float max_drive_speed;

float grey_value;
float black_and_white_diff;
float minimum_line_follow_radius;
float maximum_line_follow_radius;
float used_tape_width;

float accel_distance;
float accel_deg;

int servo_desired[4];
int servo_current[4];
float servo_time[4];
double servo_finish_time[4];

float create_right_speed;
float create_left_speed;

int create_lowest_speed;/*
typedef struct{
    double x;
    double y;
    double theta;
}position;*/


int chain_size;
int chain;
float D_Wheel_Circumference;
int right;
int left;